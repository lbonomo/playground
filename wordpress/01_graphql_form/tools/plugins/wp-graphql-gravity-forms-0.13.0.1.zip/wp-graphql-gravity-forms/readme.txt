=== WPGraphQL for Gravity Forms ===
Contributors: justlevine, kellenmace, mtdbyanechko, tinytoolbox
Tags: Forms, GraphQL, Gatsby, Headless, GF, Gravity, WPGraphQL, React
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Requires Gravity Forms: 2.7.0
Requires WPGraphQL: 1.26.0
Stable tag: 0.13.0.1
Maintained at: https://github.com/axewp/wp-graphql-gravity-forms
License: GPL-3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

== Description ==
Adds Gravity Forms functionality to the WPGraphQL schema. For more information, see [README.md](https://github.com/axewp/wp-graphql-gravity-forms/blob/main/README.md)

== Upgrade Notice == 
== Frequently Asked Questions ==
== Screenshots ==
1. Using WPGraphQL for Gravity Forms in WPGraphiQL on the WordPress backend.

== Changelog ==
**WARNING**: This release _may_ have breaking changes. Please review the release notes before updating.
[Release Notes](https://github.com/axewp/wp-graphql-gravity-forms/releases)
